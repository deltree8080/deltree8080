// index.js
import express from "express";
import cors from "cors";
import bookRoutes from "./routes/books.js";
import userRoutes from './routes/users.js';
import reviewRoutes from './routes/reviewRoutes.js'; // Import review routes

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Mount routes
app.use("/api", bookRoutes);
app.use('/api/users', userRoutes);
app.use('/api', reviewRoutes); // Add this line

app.get("/", (req, res) => {
  res.send("📚 Welcome to the Bookshop API!");
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
