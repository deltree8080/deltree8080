import { books } from '../models/books.js';

// Task 8: Add/Modify Review
export const addOrUpdateReview = (req, res) => {
  const { isbn } = req.params;
  const { review } = req.body;
  const username = req.user;

  const book = books.find(b => b.isbn === isbn);
  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }

  book.reviews[username] = review;
  res.json({ message: 'Review added/updated successfully', reviews: book.reviews });
};

// Task 9: Delete Review
export const deleteReview = (req, res) => {
  const { isbn } = req.params;
  const username = req.user;

  const book = books.find(b => b.isbn === isbn);
  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }

  if (book.reviews[username]) {
    delete book.reviews[username];
    return res.json({ message: 'Review deleted successfully', reviews: book.reviews });
  } else {
    return res.status(404).json({ error: 'Review by this user not found' });
  }
};
