const users = []; // Simulated user "database"

export const registerUser = (req, res) => {
  const { username, password } = req.body;

  // Simple validation
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password required.' });
  }

  // Check if user already exists
  const userExists = users.find(user => user.username === username);
  if (userExists) {
    return res.status(409).json({ message: 'User already exists.' });
  }

  // Add user
  users.push({ username, password });
  res.status(201).json({ message: 'User registered successfully.' });
};

// controllers/userController.js

export const loginUser = (req, res) => {
  const { username, password } = req.body;

  // Check for missing fields
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required.' });
  }

  // Find user
  const user = users.find((user) => user.username === username);

  // Validate credentials
  if (!user || user.password !== password) {
    return res.status(401).json({ message: 'Invalid username or password.' });
  }

  res.status(200).json({ message: 'Login successful.' });
};

