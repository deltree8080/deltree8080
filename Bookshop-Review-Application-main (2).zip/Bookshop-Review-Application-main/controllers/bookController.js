// controllers/bookController.js
import { books } from "../models/books.js";

export const getAllBooks = (req, res) => {
  res.json(books);
};

export const getBookByIsbn = (req, res) => {
    const { isbn } = req.params;
    const book = books.find((b) => b.isbn === isbn);
  
    if (!book) {
      return res.status(404).json({ message: "Book not found" });
    }
  
    res.json(book);
  };

  // GET /api/books/author/:authorName
export const getBooksByAuthor = (req, res) => {
    const { authorName } = req.params;
    const booksByAuthor = books.filter(
      (book) => book.author.toLowerCase() === authorName.toLowerCase()
    );
  
    if (booksByAuthor.length === 0) {
      return res.status(404).json({ message: "No books found for this author" });
    }
  
    res.json(booksByAuthor);
  };

  // GET /api/books/title/:title
export const getBooksByTitle = (req, res) => {
    const { title } = req.params;
    const booksByTitle = books.filter(
      (book) => book.title.toLowerCase() === title.toLowerCase()
    );
  
    if (booksByTitle.length === 0) {
      return res.status(404).json({ message: "No books found with this title" });
    }
  
    res.json(booksByTitle);
  };

  // GET /api/books/:isbn/reviews
export const getBookReviews = (req, res) => {
    const { isbn } = req.params;
    const book = books.find((b) => b.isbn === isbn);
  
    if (!book) {
      return res.status(404).json({ message: "Book not found" });
    }
  
    res.json({ reviews: book.reviews });
    };
  