import express from 'express';
import { addOrUpdateReview, deleteReview } from '../controllers/reviewController.js';
import { authenticateUser } from '../middleware/auth.js'; // Import the authentication middleware

const router = express.Router();

// Add or Modify Review
router.put('/books/:isbn/review', authenticateUser, addOrUpdateReview);

// Delete Review
router.delete('/books/:isbn/review', authenticateUser, deleteReview);

export default router;
