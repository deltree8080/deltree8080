// routes/bookRoutes.js
import express from "express";
import { getAllBooks, getBookByIsbn, getBooksByAuthor,getBooksByTitle, getBookReviews} from "../controllers/bookController.js";

const router = express.Router();

router.get("/books", getAllBooks);
router.get("/books/:isbn", getBookByIsbn); 
router.get("/books/author/:authorName", getBooksByAuthor); // GET /api/books/author/:authorName
router.get("/books/title/:title", getBooksByTitle); // GET /api/books/title/:title
router.get("/books/:isbn/reviews", getBookReviews);

export default router;
