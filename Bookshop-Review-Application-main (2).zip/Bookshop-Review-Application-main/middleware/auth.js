export const authenticateUser = (req, res, next) => {
    console.log('Authenticating user...');
    const username = req.headers['x-user'];
    if (!username) {
      return res.status(401).json({ error: 'Unauthorized: No username provided in headers' });
    }
    req.user = username;
    next();
  };
  