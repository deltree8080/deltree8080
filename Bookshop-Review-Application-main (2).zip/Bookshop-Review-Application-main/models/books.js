// models/books.js

export const books = [
  {
    id: 1,
    isbn: '9780439023481',
    title: 'The Hunger Games',
    author: 'Suzanne Collins',
    reviews: ['Gripping and thrilling!', 'A must-read!']
  },
  {
    id: 2,
    isbn: '9780747532743',
    title: 'Harry Potter and the Philosopher\'s Stone',
    author: 'J.K. Rowling',
    reviews: ['Magical and captivating.', 'Loved it!']
  },
  {
    id: 3,
    isbn: '9780061120084',
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    reviews: ['Powerful message.', 'Timeless classic.']
  },
  {
    id: 4,
    isbn: '9780451524935',
    title: '1984',
    author: 'George Orwell',
    reviews: ['Eerily accurate.', 'Hauntingly relevant.']
  },
  {
    id: 5,
    isbn: '9780544003415',
    title: 'The Hobbit',
    author: 'J.R.R. Tolkien',
    reviews: ['A magical adventure.', 'Perfect fantasy book.']
  },
  {
    id: 6,
    isbn: '9780316769488',
    title: 'The Catcher in the Rye',
    author: 'J.D. Salinger',
    reviews: ['Relatable and raw.', 'Thought-provoking.']
  },
  {
    id: 7,
    isbn: '9780142437209',
    title: 'Moby-Dick',
    author: 'Herman Melville',
    reviews: ['Epic tale of obsession.', 'Challenging but rewarding.']
  },
  {
    id: 8,
    isbn: '9780060850524',
    title: 'Brave New World',
    author: 'Aldous Huxley',
    reviews: ['Futuristic and profound.', 'Still feels relevant.']
  },
  {
    id: 9,
    isbn: '9780316015844',
    title: 'Twilight',
    author: 'Stephenie Meyer',
    reviews: ['Romantic and intense.', 'Fun guilty pleasure.']
  },
  {
    id: 10,
    isbn: '9780143127550',
    title: 'The Alchemist',
    author: 'Paulo Coelho',
    reviews: ['Inspirational and deep.', 'A spiritual journey.']
  }
];
