// server/index.js
import express from 'express';
import {
  getAllBooks,
  getBookByISBN,
  getBooksByAuthor,
  getBooksByTitle
} from '../clients/apiClients.js';  // Adjust path if needed


const app = express();
const PORT = 5000;

// ✅ Testing client API calls
app.get('/promise/books',  async (req, res) => {
  let data;
  try {
   data = await getAllBooks(); // Fetch all books
   console.log('📚 All Books:', data); // Log all books
  } catch (error) {
    console.error('❌ Error in client API calls:', error.message);
  }

  res.send(data);
});

app.get('/promise/books/:isbn',  async (req, res) => {
  let data;
  try {
    const { isbn } = req.params; // Extract ISBN from request parameters
    data = await getBookByISBN(isbn); // Fetch book by ISBN
   console.log('📚Isbn Book:', data); // Log all books
  } catch (error) {
    console.error('❌ Error in client API calls:', error.message);
  }

  res.send(data);
});

app.get('/promise/books/author/:author',  async (req, res) => {
  let data;
  try {
    const { author } = req.params; // Extract author from request parameters
    data = await getBooksByAuthor(author); // Fetch books by author
   console.log('📚 Author Book:', data); // Log all books
  } catch (error) {
    console.error('❌ Error in client API calls:', error.message);
  }

  res.send(data);
});

app.get('/promise/books/title/:title',  async (req, res) => {
  let data;
  try {
    const { title } = req.params; // Extract title from request parameters
    data = await getBooksByTitle(title); // Fetch books by title
   console.log('📚 Title Book:', data); // Log all books
  } catch (error) {
    console.error('❌ Error in client API calls:', error.message);
  }

  res.send(data);
});

// ✅ Task 10: Get all books


// ✅ Only one app.listen
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});

//   console.log('📚 All Books:', response.data);
