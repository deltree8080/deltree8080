// clients/apiClient.js
import axios from 'axios';

const PORT = 3000;
const BASE_URL = `http://localhost:${PORT}`;

export async function getAllBooks() {
  try {
    const url = `${BASE_URL}/api/books`;
    console.log('🔗 Fetching all books from:', url);
    const response = await axios.get(url);
    console.log('📚 All Books:', response.data);
    return response.data;

  } catch (error) {
    console.error('❌ Error fetching all books:', error.message);
  } // Return the data for further processing if needed
}
export async function getBookByISBN(isbn) {
  try {
    const response = await axios.get(`${BASE_URL}/api/books/${isbn}`);
    console.log(`🔎 Book with ISBN ${isbn}:`, response.data);
    return response.data;
  } catch (error) {
    console.error(`❌ Error fetching book by ISBN:`, error.message);
    throw error;
  }
}


export async function getBooksByAuthor(author) {
  try {
    const response = await axios.get(`${BASE_URL}/api/books/author/${encodeURIComponent(author)}`);
    console.log(`🖋️ Books by ${author}:`, response.data);
    return response.data;
  } catch (error) {
    console.error('❌ Error fetching books by author:', error.message);
  }
}

export async function getBooksByTitle(title) {
  try {
    const response = await axios.get(`${BASE_URL}/api/books/title/${encodeURIComponent(title)}`);
    console.log(`📖 Books with title "${title}":`, response.data);
    return response.data;
  } catch (error) {
    console.error('❌ Error fetching books by title:', error.message);
  }
}
